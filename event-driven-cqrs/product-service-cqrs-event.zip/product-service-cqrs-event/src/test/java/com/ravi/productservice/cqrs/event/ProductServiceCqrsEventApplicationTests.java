package com.ravi.productservice.cqrs.event;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceCqrsEventApplicationTests {

	@Test
	void contextLoads() {
	}

}
