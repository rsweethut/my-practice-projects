package com.ravi.productservice.cqrs.event;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductServiceCqrsEventApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductServiceCqrsEventApplication.class, args);
	}

}
